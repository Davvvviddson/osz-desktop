# OSz Desktop 4.1

A browser-based desktop environment with four visual desktop modes: Windows-inspired, macOS-inspired, Linux-inspired, and the original OSz design.

## Run it

1. Extract the ZIP archive.
2. Open `index.html` in a modern desktop or mobile browser.
3. If your browser restricts local file behavior, run a local server from this folder:
   - `python -m http.server 8000`
   - Visit `http://localhost:8000`

## Version 4.1 features

- Notification center with unread counts, timestamps, individual dismissal, and clear-all.
- Multiple instances of the same app, launched with the `＋` button in any app window title bar; each instance has its own taskbar entry.
- Paint Studio automatically saves artwork locally between app sessions and can export drawings as PNG.
- Desktop shortcut: `Ctrl`/`⌘` + `Space` opens the Start menu; `Escape` closes open panels.
- Paint Studio is available directly from the desktop.

## Version 3.0 features

- Animated startup screen and local profile sign-in.
- Draggable, resizable app windows with minimize, maximize, focus, and taskbar controls. Different apps and multiple instances of the same app can run side by side.
- File Explorer with locally stored text files, editing, saving, and deletion.
- App Store for installing built-in apps into the Start menu.
- Calendar with local event creation and deletion.
- Paint Studio with mouse/touch drawing, brush color, size controls, persistent local artwork, and PNG export.
- Desktop clock/date and editable quick-note widgets.
- Browser app with Direct mode, Preview mode (including optional title/description/image metadata), and optional Proxy mode.
- Proxy setup panel for connecting your own Cloudflare Worker backend; deployment files and instructions are in `proxy/`.
- OS modes, accent colors, wallpapers, glass intensity, local profiles, notes, and saved websites.

## Important limitations

- This is a front-end desktop simulation, not a real operating system. It cannot run native Windows/macOS/Linux programs or access system files.
- Direct mode still respects website embedding policies. Proxy mode requires deploying the optional Worker in `proxy/`; the Worker is not hosted for you automatically. Cloudflare currently offers a free Workers plan with a daily request allowance, but limits and eligibility can change.
- Proxy mode is a compatibility feature, not a universal browser. Some sites will still fail because of authentication, complex JavaScript, cookies, POST requests, WebSockets, DRM, streaming protections, CAPTCHAs, or origin checks. It does not bypass those controls. Use Preview mode for a compact page-information card, or open the site in your regular browser.
- OSz data is stored in browser local storage on this device. Clearing browser data can erase it. There is no cloud sync or multi-device account system.
- OSz data, notifications, calendar events, File Explorer text documents, notes, and Paint Studio artwork are stored in browser local storage on this device. Large drawings may use substantial browser storage.
- Profile sign-in is a local profile selector, not password-protected authentication.


## OSz 4.1 visual refresh

The four desktop environments now have distinct original CSS-only visual treatments: Windows-inspired Fluent blue glass, macOS-inspired warm translucent desktop and Dock, Ubuntu/GNOME-inspired aubergine shell, and the original OSz aurora theme. No third-party website screenshots or external OS artwork are used as desktop backgrounds.
